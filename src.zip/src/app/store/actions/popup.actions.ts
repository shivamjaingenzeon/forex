import { createAction } from '@ngrx/store';

export const openAddBankDetailsPopup = createAction('[Popup] Open Add Bank Details');
export const closeAddBankDetailsPopup = createAction('[Popup] Close Add Bank Details');
