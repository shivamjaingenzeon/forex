import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';

@Injectable({
    providedIn: 'root'
})
export class ScrollService {
    private scrollToConverterSource = new Subject<void>();

    // Observable stream
    scrollToConverter$ = this.scrollToConverterSource.asObservable();

    // Service message commands
    triggerScrollToConverter() {
        this.scrollToConverterSource.next();
    }
}
